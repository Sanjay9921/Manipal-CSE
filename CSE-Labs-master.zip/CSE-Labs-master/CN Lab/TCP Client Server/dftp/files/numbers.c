#include <stdio.h>

int main (int argc, const char * argv []) {
	int i;
	for (i = 0; i < 10; ++i) {
		printf("%d ", i+1);
	}
	printf("\n");
}