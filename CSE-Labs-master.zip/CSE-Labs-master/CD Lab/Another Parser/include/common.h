// Commoon header file

#ifndef IMPORT_STUFF
#define IMPORT_STUFF
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#endif

#include "util.h"


#define BUFFER_SIZE 256
#define NONE -1
#define EOS '\0'