main () {
	int x;
	char y;
	int p;
	x = p;
	x = p + x * p;
	if (x == p) {
		y = x;
	} else {
		y = p;
	}
	for (x = p; x <= p; x = x + 2) {
		y = y * 2;
	}
}
