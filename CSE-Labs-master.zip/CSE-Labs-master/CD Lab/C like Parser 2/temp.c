main () {
	int a;
	int arr[10];
	char b, c;
	a = a + 10;
	b = a * c;
}