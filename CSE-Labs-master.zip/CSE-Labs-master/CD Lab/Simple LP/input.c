main () {
	char apple, banana;
	int cat, dog;
	cat = 5;
}