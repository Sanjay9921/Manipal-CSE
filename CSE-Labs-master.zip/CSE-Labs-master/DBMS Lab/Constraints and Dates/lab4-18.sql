select empName, to_char(dob, 'DAY') from Employee;
select empName, to_char(dob, 'Day') from Employee;